% Test-Script for new Compute-Additional-Required-Algorithms

clear all;
close all;

% ILU parameter
el = 1;

MatrixNumber = 5;
% 5 funktioniert

% MatrixNumber = 4, el = 3, numproc=4,restart=4 gmres gut fuer uns
NumProc = 7;

disp('============== Begin new run ==============')
[A,MatrixName] = ReadMatrix(MatrixNumber);
% Generate right-hand side such that the exact solution
% is given by ones(N,1)
b = sum(A,2);
N = size(A,1);

if ( find(A~=0)==find(A'~=0) )
    disp('Structurally symmetric!')
end

% Decompose the matrix A into blocks of the same size.
% (The last block may have a different size.)
BlockSize = floor(N/NumProc);
Pptr    = 1:BlockSize:N;
Pptr(1) = [];
Pptr(size(Pptr,2)) = N;
Pptr = Pptr';
Qptr = Pptr;

% Sparsify the matrix A
[BlockA] = ExtractBlockDiagonal(A,Qptr,Pptr);

% Take BlockA as initially required nonzero entries and
% color BlockA. Then, compute those nonzero entries of A that
% can be added to BlockA such that the number of colors
% remains the same. We call these nonzero elements the
% potentially required nonzeros. Notice that the function
% below computes the sum of the initially required and
% potentially required nonzeros.
addpath('PotentialRequiredNonzeros');
InitRequired = spones(BlockA);
[InitPlusPotenRequired, NrCol] = postprocessingAllElements(spones(A),InitRequired);
disp(['Nr of colors = ',num2str(NrCol)]);
PotentRequired = InitPlusPotenRequired-spones(BlockA);

%spy(PotentRequired);
% subplot (2,2,1), spy(A), title('A')
% subplot (2,2,2), spy(BlockA), ...
%     title(['BlockA, block size = ',num2str(BlockSize)])
% subplot (2,2,3), spy(InitPlusPotenRequired), ...
%     title('Initially and potentially required')
% subplot (2,2,4), spy(PotentRequired), ...
%     title('Potentially required')

% ---- Symbolic ILU(el)
disp('Symbolic ILU on bipartite Graph')
[F] = BipartiteSilu(spones(BlockA),el);
FillIn = nnz(F)-nnz(BlockA);
N=spones(F);


disp('================= Summary =================')
disp(['A:                sum = ',num2str(sum(nnz(A)))])
disp(['Initially    Req: sum = ',num2str(sum(nnz(InitRequired)))])
disp(['Fill-in edges         = ',num2str(FillIn)])
disp(['Potentially  Req: sum = ',num2str(sum(nnz(PotentRequired)))])
disp('===========================================')
disp('Old-Algorithm-with new criteria')
[G] = DetAddReqWithClosedFillPaths(spones(A),BlockA,el);
disp(['Add. via     Alg: sum = ',num2str(sum(nnz(spones(G)-spones(F))))])
disp('===========================================')
disp('Compute Single-Side-Algorithm')
[G] = SingleSide(spones(A),BlockA,el,0,0);
disp(['Add. via new Alg: sum = ',num2str(sum(nnz(spones(G)-spones(F))))])
% Usage of SingleSide: 1. Argument -> Sparsity Pattern of A 
% 2. Argument -> required elements
% 3. Argument -> desired Fill-In-level 
% 4. Argument -> 1 = Reverse-Mode
% 5. Argument -> 1 = N-Passes with break if Result stable
disp('===========================================')
disp('Compute Single-Side-Algorithm')
[G] = SingleSide(spones(A),BlockA,el,0,1);
disp(['Add. via new Alg: sum = ',num2str(sum(nnz(spones(G)-spones(F))))])
% Usage of SingleSide: 1. Argument -> Sparsity Pattern of A 
% 2. Argument -> required elements
% 3. Argument -> desired Fill-In-level 
% 4. Argument -> 1 = Reverse-Mode
% 5. Argument -> 1 = N-Passes with break if Result stable
disp('===========================================')
disp('Compute Single-Side-Algorithm')
[G] = SingleSide(spones(A),BlockA,el,1,0);
disp(['Add. via new Alg: sum = ',num2str(sum(nnz(spones(G)-spones(F))))])
% Usage of SingleSide: 1. Argument -> Sparsity Pattern of A 
% 2. Argument -> required elements
% 3. Argument -> desired Fill-In-level 
% 4. Argument -> 1 = Reverse-Mode
% 5. Argument -> 1 = N-Passes with break if Result stable
disp('===========================================')
disp('Compute Single-Side-Algorithm')
[G] = SingleSide(spones(A),BlockA,el,1,1);
disp(['Add. via new Alg: sum = ',num2str(sum(nnz(spones(G)-spones(F))))])
% Usage of SingleSide: 1. Argument -> Sparsity Pattern of A 
% 2. Argument -> required elements
% 3. Argument -> desired Fill-In-level 
% 4. Argument -> 1 = Reverse-Mode
% 5. Argument -> 1 = N-Passes with break if Result stable

% Result check if needed: 
% Q=spones(G)-spones(F);
% Test=Q+spones(BlockA);
% [Fcheck] = BipartiteSilu(Test,el);
% if (spones(G)~=Fcheck)
%     disp('Something is wrong here.')
% end

