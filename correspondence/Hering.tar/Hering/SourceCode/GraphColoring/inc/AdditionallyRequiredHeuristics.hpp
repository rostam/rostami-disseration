#include "mex.h"
#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/cstdlib.hpp>
#include "boost/graph/graph_utility.hpp"
#include "datatypes.hpp"

using namespace std;
using namespace boost;

int symbolicILU(Graph& G_b, unsigned int l, unsigned int n);
int SingleSide(Graph& G_b, unsigned int n, unsigned int level, bool reverse, bool npass);
int DualSide(Graph& G_b, unsigned int n, unsigned int level,  bool reverse, bool npass);
void MergedSet (vector<DualSet>& Input);
void BiggestPair (vector<DualSet>& Input);
DualSet ComputeMaxPairs (Graph& G_b, unsigned int lvl, vector<unsigned int> FirstElem, vector<unsigned int>SecElem);
void PossibleEdges (Graph& G_b, unsigned int i, unsigned int n, unsigned int level ,  vector<unsigned int>& EPosC, vector<unsigned int>& EPosR);
int ComputeAdditionalRequired (Graph& G_b, unsigned int n, unsigned int level);
int AddEdgesOneSide(Graph& G_b,unsigned int i, unsigned int n, vector<unsigned int> EPosR, vector<unsigned int> EPosC); 
int AddEdges (Graph& G_b,unsigned int i,unsigned int n, DualSet Input); 
