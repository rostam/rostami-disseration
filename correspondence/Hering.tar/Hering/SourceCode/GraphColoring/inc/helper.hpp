#include "mex.h"
#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/cstdlib.hpp>
#include "datatypes.hpp"

using namespace std;
using namespace boost;


void createGraphFromMatrix(Graph& G_b, const mxArray *matrix);
void addWeightToGraph(Graph& G_b, const mxArray *matrix);
void createColumnVertexList(vector<unsigned int>& V, const mxArray *matrix);
void createRowVertexList(vector<unsigned int>& V, const mxArray *matrix);
void createOutputStructureMatrix(Graph& G_b, mxArray *plhs[], int m, int n,int nzmax);

