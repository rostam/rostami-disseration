#ifndef PARTIALD2COLORINGRESTRICTED_HPP
#define PARTIALD2COLORINGRESTRICTED_HPP

#include <iostream>
#include <boost/config.hpp>
#include "boost/graph/adjacency_list.hpp"
#include "boost/graph/graph_utility.hpp"
#include "datatypes.hpp"
#include "Neighbors.hpp"

using namespace std;
using namespace boost;

int PD2ColResInit(Graph& G_b, const vector<unsigned int> V);
int PartialD2ColoringRestricted(Graph& G_b, const vector<unsigned int> V);
int addAllElements(Graph& G_b, const vector<unsigned int> V);
int RandomD2ColoringRestricted(Graph& G_b, const vector<unsigned int> V);
int checkColoring(Graph& G_b, const vector<unsigned int> V);
int  addAllElementsBicoloring(Graph& G_b, const vector<unsigned int>& V_r, const vector<unsigned int>& V_c, vector<int>& color);

#endif
