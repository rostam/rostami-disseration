#include <iostream>
#include <math.h>
#include "mex.h"
#include "matrix.h"
#include "PostprocessingMethods.hpp"
#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/cstdlib.hpp>
#include <string>
#include "helper.hpp"
#include "AdditionallyRequiredHeuristics.hpp"

using namespace std;
using namespace boost;

extern void _main();

void mexFunction(int nlhs, mxArray *plhs[], 
		 int nrhs, const mxArray *prhs[])
{
  size_t m, n, om, on, NrElem, fillin, test;
  int num_color, lvl, potreq, mode, pass;
  double *level, *reverse, *iterations;
  bool revmode = false, multipass = false;
  vector<unsigned int> V;
  //Initialize Variables
  fillin = 0;
  NrElem = 0;
  
  typedef adjacency_list<vecS, vecS, undirectedS,
    property<vertex_color_t, int>,
    property<edge_weight_t, int,
    property<edge_weight2_t, int> > > Graph;
  
  if (nrhs != 5)
    mexErrMsgTxt("The number of input arguments must be 5.");
  
  /* Retrieve the input data */
  m = mxGetM(prhs[0]);
  n = mxGetN(prhs[0]);
  om= mxGetM(prhs[1]);
  on= mxGetN(prhs[1]);
  level= mxGetPr(prhs[2]);
  lvl=(int)level[0];
  reverse= mxGetPr(prhs[3]);
  mode=(int)reverse[0];
  iterations= mxGetPr(prhs[4]);
  pass=(int)iterations[0];
  if (pass == 1) {
    multipass = true; 
    cout<<"N-Pass-";
  } else {
    cout<<"1-Pass-";
  }
  if (mode == 1) {
    revmode = true;
    cout<<"Reverse-Mode"<<endl;
  } else {
    cout<<"Forward-Mode"<<endl;
  }

  /* Check whether matrices are of same dimension */
  if(m!=om || n!=on)
      mexErrMsgTxt("Order matrix must be of same dimensions.");
  
  //Initialize graph-object (boost)
  Graph G_b(m+n);
  createGraphFromMatrix(G_b,prhs[0]);
  
  //put weight to graph
  addWeightToGraph(G_b,prhs[1]);
  
  //create vertice list
  createColumnVertexList(V,prhs[1]);
  NrElem=mxGetNzmax(prhs[1]);

  // do computation first for all Elements
  PD2ColResInit(G_b,V);
  num_color = PartialD2ColoringRestricted(G_b,V);
  potreq = addAllElements(G_b,V);
  //checkColoring(G_b,V);

  //cout<<"Symbolic factorization on bipartite Graph."<<endl;
  fillin=symbolicILU(G_b, lvl,(unsigned int) n);
  NrElem=mxGetNzmax(prhs[1]);
  NrElem=NrElem+fillin;

  // Compute additional required elements
  fillin=DualSide(G_b, (unsigned int) n,lvl,revmode, multipass);
  NrElem=NrElem+fillin;

  // output data 
  createOutputStructureMatrix(G_b,plhs,m,n,NrElem);
  plhs[1] = mxCreateDoubleMatrix(1,1,mxREAL);
  //double* num = mxGetPr(plhs[1]);
  //num = num_color;
}
