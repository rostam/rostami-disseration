#include <iostream>
#include <math.h>
#include "mex.h"
#include "matrix.h"
#include "PostprocessingMethods.hpp"
#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/cstdlib.hpp>
#include <string>
#include "helper.hpp"
#include "AdditionallyRequiredHeuristics.hpp"

using namespace std;
using namespace boost;

extern void _main();

void mexFunction(int nlhs, mxArray *plhs[], 
		 int nrhs, const mxArray *prhs[])
{
  size_t m, n, om, on, NrElem, fillin, test;
  int num_color, lvl, potreq;
  double* level;
  vector<unsigned int> V;
  //Initialize Variables
  fillin = 0;
  NrElem = 0;
  
  typedef adjacency_list<vecS, vecS, undirectedS,
    property<vertex_color_t, int>,
    property<edge_weight_t, int,
    property<edge_weight2_t, int> > > Graph;
  
  if (nrhs != 2)
    mexErrMsgTxt("The number of input arguments must be 2.");
  
  /* Retrieve the input data */
  m = mxGetM(prhs[0]);
  n = mxGetN(prhs[0]);
  level= mxGetPr(prhs[1]);
  lvl=(int)level[0];

  
  //Initialize graph-object (boost)
  Graph G_b(m+n);
  createGraphFromMatrix(G_b,prhs[0]);
  
  //put weight to graph
  addWeightToGraph(G_b,prhs[0]);
  //PD2ColResInit(G_b,V);
  //num_color = PartialD2ColoringRestricted(G_b,V);
  //potreq = addAllElements(G_b,V);
 
  //cout<<"Symbolic factorization on bipartite Graph."<<endl;
  fillin=symbolicILU(G_b, (unsigned int) lvl, (unsigned int) n);
  NrElem=mxGetNzmax(prhs[0]);
  NrElem=NrElem+fillin;

  // output data 
  createOutputStructureMatrix(G_b,plhs,m,n,NrElem);
  plhs[1] = mxCreateDoubleMatrix(1,1,mxREAL);
  //double* num = mxGetPr(plhs[1]);
  //num = num_color;
}
