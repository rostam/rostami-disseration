% Symbolic ILU-Factorization on a Bipartite Graph. Returns 
% the Matrix containing the required elements M and the 
% occuring Fill-Ins with Level <= el. 
%
% Returns: R_init + Fill-Ins
%
% Usage: BipartiteSilu(M,el)
