% Given set of required elements M und a set of possible edges N
% this algorithms creates the corresponding bipartite graph. Then
% it computes the occuring Fill-Ins created by M. Then it checks 
% for every edge e in N if all new Fill-Paths created by e which 
% would create a Fill-In with Level <= el are closed by an edge 
% in M or the Fill-Ins created via M. If so add e to the Graph.
%
% Returns: R_init + Fill-In + R_add
%
% Usage DetAddReqWithClosedFillPaths(N,M,el)
%
% For additional information read diploma-thesis "Ein bipartites
% graphmodell zur Vorkonditionierung von dünnbesetzten Gleichungs-
% systemen".
