% DualSide creates a bipartite Graph representing the matrix 
% given by the sparsity pattern A. First computes a coloring 
% for the required elements R_init and determines which elements 
% of A respect the coloring. Then computes the Fill-Ins created 
% by B. Finally it visits all pairs of nodes r_i,c_i trying to 
% compute a biggest set of edges from both nodes respecting the
% coloring and not creating additional fill-Ins. The order of 
% visited nodes can be specified by parameters. Returns 
% R_init + Fill-In + R_add as Matrix.
%
% Usage of DualSide(spones(A),BlockA,el,1,0);
% 1. Argument -> Sparsity Pattern of A 
% 2. Argument -> required elements
% 3. Argument -> desired Fill-In-level 
% 4. Argument -> 1 = Reverse-Mode, 
%                0 = Forward-Mode
% 5. Argument -> 1 = N-Passes with break if Result stable, 
%                0 = 1-Pass
%
% For further information read diploma thesis "Ein bipartites 
% Graphmodell zur Vorkonditionierung von dünnbesetzten 
% Gleichungssystemen" 

