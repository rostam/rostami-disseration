#include <iostream>
#include <math.h>
#include "mex.h"
#include "matrix.h"
#include "PostprocessingMethods.hpp"
#include <boost/config.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/cstdlib.hpp>
#include <string>
#include "helper.hpp"

using namespace std;
using namespace boost;

extern void _main();

void mexFunction(int nlhs, mxArray *plhs[], 
		 int nrhs, const mxArray *prhs[])
{
  size_t m, n, om, on;
  int num_color;
  vector<unsigned int> V;

  typedef adjacency_list<vecS, vecS, undirectedS,
    property<vertex_color_t, int>,
    property<edge_weight_t, int, 
    property<edge_weight2_t, int> > > Graph;
  
  if (nrhs != 2)
    mexErrMsgTxt("The number of input arguments must be 2.");
  
  /* Retrieve the input data */
  m = mxGetM(prhs[0]);
  n = mxGetN(prhs[0]);
  om= mxGetM(prhs[1]);
  on= mxGetN(prhs[1]);

  /* Check whether matrices are of same dimension */
  if(m!=om || n!=on)
      mexErrMsgTxt("Order matrix must be of same dimensions.");
  
  //Initialize graph-object (boost)
  Graph G_b(m+n);
  createGraphFromMatrix(G_b,prhs[0]);
  
  //put weight to graph
  cout<<"about to add weight"<<endl;
  addWeightToGraph(G_b,prhs[1]);
  
  cout<<"added weight"<<endl;
  //create vertice list
  createColumnVertexList(V,prhs[1]);
      
  // do computation first for all Elements
  PD2ColResInit(G_b,V);
  num_color = PartialD2ColoringRestricted(G_b,V);
  cout<<"# new Elements using all: "<<addAllElements(G_b,V)<<endl;
  //checkColoring(G_b,V);
  
  //due to modified helper.cpp add weight2 for all computed edges.
  graph_traits<Graph>::edge_iterator ei, ei_end;
  property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
  property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
  for (tie(ei, ei_end) = edges(G_b); ei != ei_end; ++ei){
    if (get(weight,*ei) == 1){
      put(weight2,*ei,0);
    }   
  }     
  // output data 
  createOutputStructureMatrix(G_b,plhs,m,n,mxGetNzmax(prhs[0]));
  plhs[1] = mxCreateDoubleMatrix(1,1,mxREAL);
  double* num = mxGetPr(plhs[1]);
  *num = num_color;
}
