#include "helper.hpp"
#include "datatypes.hpp"
#include "AdditionallyRequiredHeuristics.hpp"
#include <iostream>

/* For detailed informations about the following algorithms read 
 * diploma-thesis "Ein bipartites Graphmodell zur Vorkonditionierung
 * von duennbesetzten Gleichungssysteme" 
 */ 

int symbolicILU(Graph& G_b, unsigned int l, unsigned int n){
  /* Given G_b, Level l, Dimension n of Matrix A: 
   * Computes symbolic ILU on G_b and returns 
   * number of Fill-Ins
   */
  int lvlnew = 0 ;
  unsigned int EStart = 0, EEnd = 0;
  int CountFillins = 0;
  graph_traits<Graph>::out_edge_iterator oei, oei_end;
  graph_traits<Graph>::out_edge_iterator oei2, oei2_end;
  graph_traits<Graph>::edge_descriptor e;
  property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
  property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
  for(unsigned int i = 0; i < n; i++){
    for (tie(oei,oei_end)=out_edges(i,G_b); oei!=oei_end;oei++){
    /* Only neighbors with Index > i can be inner node of a Fillpath */
      if(target(*oei,G_b)>n+i && get(edge_weight2,G_b,*oei)!=(unsigned int)-1){
        EStart=(unsigned int)target(*oei,G_b);
        for(tie(oei2,oei2_end)=out_edges(i+n,G_b); oei2!=oei2_end;oei2++){
          /* only neighbors with Index > i (-> column > n+i) can be inner node of a Fillpath */
          if(target(*oei2,G_b)>i && get(edge_weight2,G_b,*oei2)!=(unsigned int)-1){
            EEnd=(unsigned int)target(*oei2,G_b);
            lvlnew = get(edge_weight2,G_b,*oei) + get(edge_weight2,G_b,*oei2) + 1;
            if(lvlnew >= 0 && lvlnew < l+1){
              if(edge(EStart,EEnd,G_b).second==1){
                e=edge(EStart,EEnd,G_b).first;
              } else {
              add_edge(EStart,EEnd, 0, G_b);
              e = edge(EStart,EEnd,G_b).first;
	      }
              if(get(weight,e) != 1){
                put(weight,e,1);
                CountFillins++;
	      }
              if (lvlnew< get(weight2,e)){
	          put(weight2,e,lvlnew);
              }
	    }   	
          }	
        }
      }
    }
  }
  //cout<<"fill-ins found:"<<CountFillins<<endl;
  return(CountFillins);
}

/* Checks for every edge if it creates a Fill-Path which leads to new Fill-Ins
 * If not adds it to the Graph. 
 */
int ComputeAdditionalRequired (Graph& G_b, unsigned int n, unsigned int level){
  graph_traits<Graph>::out_edge_iterator oei, oei_end;
  graph_traits<Graph>::out_edge_iterator oei2, oei2_end;
  graph_traits<Graph>::edge_descriptor e;
  property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
  property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
  bool possible = true;
  unsigned int candidate = 0, EEnd = 0, counter = 0;
  for (unsigned int i = 0; i < n; i++) {
    for (tie(oei,oei_end)=out_edges(i,G_b); oei!=oei_end; oei++){
    /* check whether edge respects coloring (weight = 1) and
     * check whehter edge isn't already computed (weight2)==-1
     */
      if (get(weight,*oei)==1 && get(weight2,*oei)==(unsigned int)-1 ){
        candidate=(unsigned int)target(*oei,G_b);
        possible=true;
        if (candidate > n+i){
          for(tie(oei2,oei2_end)=out_edges(n+i,G_b); oei2!=oei2_end; oei2++){
            EEnd=(unsigned int)target(*oei2,G_b);
            if(EEnd > i && get(weight,*oei2)==1 && get(weight2,*oei2)>=0 && get(weight2,*oei2) < level){
              if (edge(EEnd,candidate,G_b).second == 0 || get(weight,edge(EEnd,candidate,G_b).first) == 0
              || get(weight2,edge(EEnd,candidate,G_b).first) == (unsigned int)-1){
               possible=false;
              }
            }
          }
        }
        if (candidate < n+i){
          for(tie(oei2,oei2_end)=out_edges(candidate-n,G_b); oei2!=oei2_end; oei2++){
          EEnd=(unsigned int)target(*oei2,G_b);
            if(EEnd > candidate && get(weight,*oei2)==1 && get(weight2,*oei2)>=0 && get(weight2,*oei2) < level){
              if (edge(i,EEnd,G_b).second == 0 || get(weight,edge(i,EEnd,G_b).first) == 0
              || get(weight2,edge(i,EEnd,G_b).first) == (unsigned int)-1){
                possible=false;
              }
            }
          }
        }
        if (candidate == n+i){possible= false;} /*Diagonal-edge -> always contained*/
        if (possible == true) {
          put(weight2,*oei,0);
          counter++;
        }
      }
    }
  }
  return(counter);
}

/* Dual-Side: For every pair of nodes r_i,c_i Dual-Sides finds a set of edges outgoing from
 * both nodes which do not create additional Fill-Ins. Uses "possible edge" to find all edges
 * which do not create Fill-Ins. Then uses ComputeMaxPairs to find the biggest Pos_c_i(c_p)
 * and the biggest Pos_r_i(r_l). Chooses the bigger one and adds it to the graph.
 */ 
int DualSide(Graph& G_b,unsigned int n, unsigned int level, bool reverse, bool npass) {
  vector<unsigned int> EPosR;
  vector<unsigned int> EPosC;
  DualSet ColResult,RowResult;
  bool possible = true;
  unsigned int candidate = 0, EEnd = 0,counter = 0, RowEdges = 0, ColEdges = 0;
  unsigned int OneSideRow, OneSideCol, OneSideMax, DualSideMax, i, iterations, newedges;
  if (npass == true) {
    iterations = n;
  } else {
    iterations = 1;
  }
  for (unsigned int j=0; j < iterations; j++){
    newedges=0;
    for (unsigned int l=0; l < n; l++){
      RowResult.first.clear();
      RowResult.second.clear();
      ColResult.first.clear();
      ColResult.second.clear();
      EPosC.clear();
      EPosR.clear();
      if (reverse == true) { 
        i = n-1-l;
      } else {
        i = l ;
      }
      PossibleEdges(G_b,i,n,level,EPosC,EPosR);
      /*initialize Pairs of possible Edges from Node r_i and count # possible Edges*/ 
      RowResult=ComputeMaxPairs(G_b,level,EPosC,EPosR);
      RowEdges=RowResult.first.size() + RowResult.second.size();
      /*Now Check Pairs of possible Edges from Node c_i and count # of possible Edges */
      ColResult=ComputeMaxPairs(G_b,level,EPosR,EPosC);
      ColEdges=ColResult.first.size() + ColResult.second.size();
      OneSideCol=EPosC.size();
      OneSideRow=EPosR.size();
      if (OneSideCol > OneSideRow) { OneSideMax=OneSideCol;} else {OneSideMax = OneSideRow;}
      if (ColEdges < RowEdges) {DualSideMax = RowEdges;} else {DualSideMax = ColEdges;}
      if (OneSideMax > DualSideMax){
        newedges=newedges + AddEdgesOneSide(G_b, i, n, EPosR, EPosC);
      } else {
        if (ColEdges < RowEdges && RowEdges != 0 ){
          newedges=newedges + AddEdges(G_b,i,n,RowResult);
        } else { 
          if (ColEdges != 0 ){
            newedges=newedges + AddEdges(G_b,i,n,ColResult);
          }
        }
      }
    }
    counter = counter + newedges;
    if (newedges == 0) {
      cout<<"Result stable after "<<j<<" Iteration(s)."<<endl;
      j = iterations;
    }
  }
  return(counter);
}



/* Single-Side algorithm: For a pair of nodes r_i,c_i Single-Side computes the 
 * two sets of outgoing edges from node r_i and c_i which do not create new Fill-Ins
 * chooses the bigger set and adds it to the Graph for all i. 
 */
int SingleSide(Graph& G_b, unsigned int n, unsigned int level, bool reverse, bool npass){
  vector<unsigned int> ERow;
  vector<unsigned int> ECol;
  unsigned int counter = 0, i = 0, iterations, newedges;
  unsigned int test1 = 0, test2 =0, test3= 0, test4 =0;
  ERow.reserve(n+n);
  ECol.reserve(n+n);
  if (npass == true) {
    iterations = n;
  } else {
    iterations = 1;
  }
  for (unsigned int j=0; j < iterations; j++){
    newedges=0;
    for (unsigned int l=0; l < n; l++){
      ECol.clear();
      ERow.clear();
      if (reverse == true) { 
        i = n-1-l;
      } else {
        i = l ;
      }
      //Compute Possible Edges
      PossibleEdges(G_b,i,n,level,ECol,ERow);
      //Choose Side with more Edges possible and add them to Graph 
      newedges = newedges + AddEdgesOneSide(G_b, i, n, ERow, ECol);
    }
    counter=counter+newedges;
    if (newedges == 0) {
      cout<<"Result stable after "<<j<<" Iterations."<<endl;
      j = iterations;
    }
  }
  return(counter);
}


/***************************************************************************************
 *
 *              Part of both Algorithms : Single-Side & Dual Side 
 *
 *      The following Procedure computes the Targets of possible 
 *      Edges starting from the pair of nodes r_i,c_i - restricted 
 *               by not creating additional Fill-Ins. 
 * 
 ***************************************************************************************/
void PossibleEdges (Graph& G_b, unsigned int i, unsigned int n, unsigned int level ,  vector<unsigned int>& EPosC, vector<unsigned int>& EPosR) {
  graph_traits<Graph>::out_edge_iterator oei, oei_end;
  graph_traits<Graph>::out_edge_iterator oei2, oei2_end;
  graph_traits<Graph>::edge_descriptor e;
  property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
  property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
  bool possible = true;
  unsigned int candidate = 0, EEnd = 0;
  for (tie(oei,oei_end)=out_edges(i,G_b); oei!=oei_end; oei++){
    /* Consider only Edges from R_i with target node C_j, j > i 
     * (since it's a Column -> j > n+i)
     * - respecting coloring (weight == 1) and are 
     * - not computed yet (weight2 == (unsigned int) -1)
     */
    candidate=(unsigned int)target(*oei,G_b);
    if(candidate > n+i && get(weight,*oei)==1 && get(weight2,*oei)==(unsigned int)-1){
      possible=true;
      /* Test if all (Fill-)Paths created by outgoing edges from C_i 
       * (-> r_l, l > i, weight = 1, with Level =< L) can be completed 
       * to circles of length four using already contained edges.
       */
      for(tie(oei2,oei2_end)=out_edges((unsigned int)i+n,G_b); oei2!=oei2_end; oei2++){
        EEnd=(unsigned int)target(*oei2,G_b);
        if(EEnd > i && get(weight,*oei2)==1 && get(weight2,*oei2)>=0 && get(weight2,*oei2)<level){
          if (edge(EEnd,candidate,G_b).second == 0 || get(weight,edge(EEnd,candidate,G_b).first) == 0
            || get(weight2,edge(EEnd,candidate,G_b).first) == (unsigned int)-1){
            possible=false; 
          }
        }
      }
      /* Add candidate to Vector containing Possible Edges from Node R_i */
      if (possible == true){ 
        EPosR.push_back(candidate);
      }
    }
  }
  sort(EPosR.begin(),EPosR.end());
  vector<unsigned int>::iterator new_end = unique(EPosR.begin(), EPosR.end());
  EPosR.resize(distance(EPosR.begin(),new_end));

  for (tie(oei,oei_end)=out_edges((unsigned int)i+n,G_b); oei!=oei_end; oei++){
  /* Like before consider now outgoing from node C_i (Column-node: > n+i)
   * conditions for edges are the same as above !
   */
    candidate=(unsigned int) target(*oei,G_b);
    if(candidate > i && get(weight,*oei)==1 && get(weight2,*oei)==(unsigned int)-1){
      possible=true;
      /* Test if all (Fill-)Paths created by outgoing edges from R_i
       * can be completed to circles of length four.
       */
      for(tie(oei2,oei2_end)=out_edges(i,G_b); oei2!=oei2_end; oei2++){
        EEnd=(unsigned int) target(*oei2,G_b);
        if(EEnd > n+i && get(weight,*oei2)==1 && get(weight2,*oei2)>=0 && get(weight2,*oei2)<level){
          if (edge(EEnd,candidate,G_b).second == 0 || get(weight,edge(EEnd,candidate,G_b).first)== 0
            || get(weight2,edge(EEnd,candidate,G_b).first) == (unsigned int)-1){
            possible=false;
          }
        }
      }
      /* Add candidate to Vector containing Possible Edges from Node C_i */
      if (possible == true){ 
        EPosC.push_back(candidate);
      }
    }
  }
  sort(EPosC.begin(),EPosC.end());
  vector<unsigned int>::iterator new_end2 = unique(EPosC.begin(), EPosC.end());
  EPosC.resize(distance(EPosC.begin(),new_end2));
}

/* The following function chooses the bigger Set of possible edges starting from 
 * the pair r_i,c_i and adds the corresponding edges to the graph. Returns the 
 * number of added edges, respective a MexError-Message if one of the mentioned 
 * edges is not found in G_b. 
 */
int AddEdgesOneSide(Graph& G_b, unsigned int i, unsigned int n, vector<unsigned int> EPosR, vector<unsigned int> EPosC) {
   graph_traits<Graph>::edge_descriptor e;
   property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
   bool correct = true;
   unsigned int counter = 0;
   if (EPosC.size() > EPosR.size() ){
     for(int j = 0; j< EPosC.size() ; j++){
       if(edge(EPosC[j],(unsigned int)n+i,G_b).second==1){
         e = edge(EPosC[j],(unsigned int)n+i,G_b).first;
         put(weight2,e,0);
         counter++;
       } else {
         correct=false;
       }
     }
   } else { 
     for(int j = 0; j< EPosR.size() ; j++){
       if(edge((unsigned int)i,EPosR[j],G_b).second==1){
         e = edge((unsigned int)i,EPosR[j],G_b).first;
         put(weight2,e,0);
         counter++;
       } else {
         correct=false;
       }
     }
  } 
  if(correct == false){
   mexErrMsgTxt("Computed Edge not found.");
  }
  return(counter);
}





/*******************************************************************************************************
 *
 *                          Now only parts of DualSide-Algorithm
 *
 ******************************************************************************************************/ 




/* Constructs an Array with Pairs of possible combinations of 
 * Elements of the input vectors, using "MergedSet" to merge similar
 * sets and estimates the biggest possible Set using "BiggestPair". 
 */
DualSet ComputeMaxPairs (Graph& G_b, unsigned int lvl, vector<unsigned int> FirstElem, vector<unsigned int>SecElem){
  DualSet Result;
  unsigned int x,y;
  Result.first.clear();
  Result.second.clear();
  if(FirstElem.size() != 0 && SecElem.size() != 0){
    vector<DualSet> DualSide;
    DualSet Konstruktor;
    property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
    property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
    /*initialize Pairs of possible Edges*/ 
    for(unsigned int j = 0; j< FirstElem.size() ; j++){
      Konstruktor.first.clear();
      Konstruktor.second.clear();
      x = FirstElem[j];
      Konstruktor.first.push_back(x);
      for(unsigned int k = 0; k < SecElem.size(); k++){
        y = SecElem[k];
        /* the fillpath x -> i -> i -> y for edges (x,i) - (y,i) from R_pot 
         * doesn't create addtional Fill-Ins if Edge x -> y already exists 
         * or the Level of the ILU-Factorization is 0 */ 
        if (lvl == 0) { 
            Konstruktor.second.insert(y);
        } else {
          if(edge(x,y,G_b).second==1 && get(weight2,edge(x,y,G_b).first)!=(unsigned int) -1 && get(weight,edge(x,y,G_b).first) ==1){
            Konstruktor.second.insert(y);
          }         
        }
      }
      sort(Konstruktor.first.begin(),Konstruktor.first.end());
      vector<unsigned int>::iterator new_end = unique(Konstruktor.first.begin(), Konstruktor.first.end());
      Konstruktor.first.resize(distance(Konstruktor.first.begin(),new_end));
      DualSide.push_back(Konstruktor);
    }
    if(DualSide.size() != 0){
      /* now find all possible combination find the biggest and deletes all other.*/
      MergedSet(DualSide);
      BiggestPair(DualSide);
      Result=DualSide[0];
    }
    DualSide.clear();
 }
 return(Result);
}


/* MergedSet gets Pairs of Sets, combines Sets which second component 
 * are similar (part of)
 */
void MergedSet (vector<DualSet>& Input){
  DualSet Collector;
  DualSet Testee;
  vector<DualSet> Output;
  set<unsigned int>::iterator test;
  bool possible = true;
  unsigned int TestElem;
  /*Merge First Elements, which Second Elements are similar*/
  for(unsigned int l = 0; l < Input.size(); l++){
    Collector.first.clear();
    Collector.second.clear();
    Collector = Input[l];  // Collecting Set 
    for(unsigned int o = 0; o < Input.size(); o++){
      Testee.first.clear();
      Testee.second.clear();
      Testee = Input[o];   // Candidate for merging -> Collecting.second must be part of Testee.second
      possible = true;
      // For all Elements of Collector.second test whether there's a match in Testee.second.
      for (test = Collector.second.begin(); test != Collector.second.end(); test++){
        TestElem = *test;
        if(Testee.second.find(TestElem)==Testee.second.end()){
          possible = false; // TestElem not in Testee.second -> Pointer to End -> do not merge !
        }
      }  // All Elements checked -> possible still true ?
      if (possible == true ){
        Collector.first.push_back(Testee.first[0]);
      }
      sort(Collector.first.begin(),Collector.first.end());
      vector<unsigned int>::iterator new_end = unique(Collector.first.begin(), Collector.first.end());
      Collector.first.resize(distance(Collector.first.begin(),new_end));
    } //All Pairs checked whether they're collectable -> update Setarray !
    Output.push_back(Collector);
    sort(Output.begin(),Output.end());
    vector<DualSet>::iterator new_end = unique(Output.begin(), Output.end());
    Output.resize(distance(Output.begin(),new_end));
  } // Output contains all possible combinations of edges. Now Clean up Input-Vector !
  Input.clear();
  Input=Output;
}




/* The Following function finds the biggest DualSet in Vector 
 * "Input" and deletes all other Sets
 */
void BiggestPair (vector<DualSet>& Input){
  DualSet Maximum, Testee;

  Maximum.first.clear();
  Maximum.second.clear();
  int countedges1 = 0, countedges2 = 0;
  if (Input.size() > 1 ){ // Test if there's more than one pair of Sets. If not -> nothing's to do.
    Maximum.first.clear();
    Maximum.second.clear();
    Maximum = Input[0];
    countedges1=Maximum.first.size() + Maximum.second.size ();
    for(unsigned int m = 0; m < Input.size() ; m++){
      Testee.first.clear();
      Testee.second.clear();
      Testee = Input[m];
      countedges2=Testee.first.size() + Testee.second.size();
      if(countedges2 > countedges1) { // if Testee contains more Elements than Collector
        Maximum = Testee;             // -> keep Testee and Update Elements
        countedges1 = countedges2;      // 
      } // else do nothing (-> keep Collector)
    }
    Input.clear();   // Input-Vector should only contain the biggest Pair -> delete everything contained
    if (Maximum.first.size() != 0){ // -> Collector not empty !
      Input.push_back(Maximum); // Add biggest Pair 
    }
  }
}


/* The following function gets a DualSet (vector(int),set(int)) and adds
 * the contained elements to G_b. Reports an error if one of the mentioned
 * edges is not found => the preceeding algorithms messed up something.
 */
int AddEdges (Graph& G_b,unsigned int i,unsigned int n, DualSet Input){
  graph_traits<Graph>::edge_descriptor e;
  property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
  property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
  unsigned int target, counter=0,counter2 = 0;
  bool correct = true;
  set<unsigned int>::iterator sit;
  if (Input.first.size() > 0){
    for (unsigned int j = 0; j < Input.first.size(); j++){
      correct = true;
      target = Input.first[j];
      if (target > n-1){ // target > n-1 => Column-Node
        if(edge(i,target,G_b).second == 1){
          e=edge(i,target,G_b).first; 
          if (get(weight,e) == 1) { //check whether Edge respects given Coloring or not
            put(weight2,e,0);
            counter++;
          } else {
            correct=false;
          }
        } else { //edge not found -> something's wrong here
          counter2++;
          //cout<<"Missing Edge : "<<i<<","<<target<<endl;
          correct=false;
        }
      } else {
        if(edge(target,(unsigned int)n+i,G_b).second == 1){
          e=edge(target,(unsigned int)n+i,G_b).first; 
          if (get(weight,e) == 1) { //check whether Edge respects given Coloring or not
            put(weight2,e,0);
            counter++;
          } else {
            correct=false;
          }
        } else { //edge not found -> something's wrong here
          counter2++;
          //cout<<"Missing Edge2 : "<<i<<","<<target<<endl;
          correct=false;
        }
      }
    }
    for(sit = Input.second.begin(); sit != Input.second.end(); sit++){
      target = *sit;
      if (target > n-1){ // target > n-1 => Column-Node
        if(edge(i,target,G_b).second == 1){
          e=edge(i,target,G_b).first; 
          if (get(weight,e) == 1) { //check whether Edge respects given Coloring or not
            put(weight2,e,0);
            counter++;
          } else {
            correct=false;
          }
        } else { //edge not found -> something's wrong here
          counter2++;
          //cout<<"Missing Edge : "<<i<<","<<target<<endl;
          correct=false;
        }
      } else {
        if(edge(target,(unsigned int)n+i,G_b).second == 1){
          e=edge(target,(unsigned int)n+i,G_b).first; 
          if (get(weight,e) == 1) { //check whether Edge respects given Coloring or not
            put(weight2,e,0);
            counter++;
          } else {
            correct=false;
          }
        } else { //edge not found -> something's wrong here
          counter2++;
          //cout<<"Missing Edge2 : "<<i<<","<<target<<endl;
          correct=false;
        }
      }

    }
    if(correct == false){
      mexErrMsgTxt("Computed Edge not found.");
    }
  }
  if (counter2 != 0) {
    cout<<"Nicht gefundene Kanten: "<<counter2<<endl;
    cout<<"Fehler bei Index i"<<i<<endl;
  }
  return(counter);
}


