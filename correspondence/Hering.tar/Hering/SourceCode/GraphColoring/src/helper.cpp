#include "helper.hpp"
#include <iostream>


/* This function transforms a given matrix into the corresponding
 * bipartite graph and stores it in G_b
 */
void createGraphFromMatrix(Graph& G_b, const mxArray *matrix){
  // only sparse matrices are supported
  if(mxIsSparse(matrix)){
    size_t m, n;
    
    m = mxGetM(matrix);
    n = mxGetN(matrix);
  
    mwIndex *ir, *jc;
    ir = mxGetIr(matrix);
    jc = mxGetJc(matrix);
    property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
    property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
    graph_traits<Graph>::edge_descriptor e;
    unsigned int nzmax = mxGetNzmax(matrix);
    for( int i = 0; i < n; i++){
      int j = 0;
      while( jc[i]+j < jc[i+1] && jc[i]+j < nzmax){
	add_edge( (unsigned int)ir[jc[i]+j], (unsigned int) i+m, 0, G_b );
        e = edge( (unsigned int)ir[jc[i]+j], (unsigned int)i+m, G_b).first;
	put(weight,e,0);
	put(weight2,e,(unsigned int)-1);
	j++;
      }
    }
  } else{
    mexErrMsgTxt("Matrix has to be sparse!");
  }
}

/* Given a graph and a matrix containing some of the graph's edges,
 * the weight of the edges contained in the matrix is set to 1
 * For symbolic ILU initialize all Entries of the Matrix with 0. 
 */
void addWeightToGraph(Graph& G_b, const mxArray *matrix){
  if(mxIsSparse(matrix)){
    size_t m, n;
  
    m = mxGetM(matrix);
    n = mxGetN(matrix);
    mwIndex *ir, *jc;
    ir = mxGetIr(matrix);
    jc = mxGetJc(matrix);
    unsigned int nzmax = mxGetNzmax(matrix);
    property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
    property_map<Graph, edge_weight2_t>::type weight2 = get(edge_weight2,G_b);
    graph_traits<Graph>::edge_descriptor e;
    for(int i=0; i < n; i++){
      int j=0;
      while( jc[i]+j < jc[i+1] && jc[i+1] <= nzmax ){
	if( edge( (unsigned int)ir[jc[i]+j], (unsigned int)i+m, G_b).second){
	  e = edge( (unsigned int)ir[jc[i]+j], (unsigned int)i+m, G_b).first;
	  put(weight,e,1);
	  put(weight2,e,0);
	}
	j++;
      }
    }
  } else{
    mexErrMsgTxt("Matrix of required elements has to be sparse!");
  }
}



/* Given a matrix, a vector containing all the vertex names of 
 * vertices referencing non-empty columns is created and stored in V
 */
void createColumnVertexList(vector<unsigned int>& V, const mxArray *matrix){
  if(mxIsSparse(matrix)){
    size_t m, n;
    
    m = mxGetM(matrix);
    n = mxGetN(matrix);
    
    mwIndex *jc;
    jc = mxGetJc(matrix);
    
    for(unsigned int i=0; i<n; i++){
      //if(jc[i+1] > jc[i])
      V.push_back(i+m);
    }
  } else{
    mexErrMsgTxt("Matrix of required elements has to be sparse!");
  }
}

/* Given a matrix, a vector containing all the vertex names of 
 * vertices referencing non-empty columns is created and stored in V
 */
void createRowVertexList(vector<unsigned int>& V, const mxArray *matrix){
  if(mxIsSparse(matrix)){
    size_t m, n;
    
    m = mxGetM(matrix);
    n = mxGetN(matrix);
    
    mwIndex *jc;
    jc = mxGetJc(matrix);
    
    for(unsigned int i=0; i<m; i++){
      //if(jc[i+1] > jc[i])
      V.push_back(i);
    }
  } else{
    mexErrMsgTxt("Matrix of required elements has to be sparse!");
  }
}

/* This function takes a graph and a Matlab-output array as well as some
 * size descriptions and transforms the graph into an output structure
 * matrix of the given size, i.e. the matrix contains a 1 on exactly
 * those positions (i,j) where the weight of the edge from row-vertex i
 * to column-vertex j is equal to 1
 */
void createOutputStructureMatrix(Graph& G_b, mxArray *plhs[], int m, int n,int nzmax){
  plhs[0] = mxCreateSparse(m,n,nzmax,mxREAL);

  mwSize j;
  mwIndex *ir, *jc;
  double *pr;
  graph_traits<Graph>::adjacency_iterator ai, ai_end;
  ir = mxGetIr(plhs[0]);
  jc = mxGetJc(plhs[0]);
  pr = mxGetPr(plhs[0]);
  int k=0;
  for(j=0;j<n;j++){
    jc[j]=k;
    for(tie(ai,ai_end)=adjacent_vertices((unsigned int)j+m,G_b);ai!=ai_end;ai++){
      if(get(edge_weight,G_b,edge(*ai,(unsigned int)j+m,G_b).first)==1){
	if(get(edge_weight2,G_b,edge(*ai,(unsigned int)j+m,G_b).first)!=(unsigned int)-1){
          ir[k]=*ai;
	  pr[k]=1;
	  k++;
	}
      }
    }
  }
  jc[n]=k;
}


