#include "PostprocessingMethods.hpp"

/* Initializes the colors for PartialD2Coloring */
int PD2ColResInit(Graph& G_b, const vector<unsigned int> V)
{
  property_map<Graph, vertex_color_t>::type color=get(vertex_color,G_b);
  //Initialize colors
  for (vector<unsigned int>::const_iterator v = V.begin(); v != V.end(); ++v)  {
    put(color,*v,0);
  }
  
}

/* After the coloring has been initialized, this method performs a run of 
 * PartialD2ColoringRestricted, using the given vertex list*/
int PartialD2ColoringRestricted(Graph& G_b, const vector<unsigned int> V)
{
  property_map<Graph, vertex_color_t>::type color = get(vertex_color, G_b);
  vector<unsigned int> N_2;
  vector<unsigned int> forbiddenColors(num_vertices(G_b),-1);
  //All edges in E_S have edge_weight=1; otherwise edge_weight=0
  
  //Iterate over all vertices which should be colored
  for (vector<unsigned int>::const_iterator v = V.begin(); v != V.end(); ++v) 
  {
    
    //Color 0 should not be assigned
    forbiddenColors[0]=*v;
    
    //Get the distance-2 neighbors
    N_2 = neighbors::N_2restricted(G_b,*v);
    
    //Iterate over distance-2 neighbors
      //cout<<"dist2-neighbors:\n";
    for (vector<unsigned int>::iterator n_2 = N_2.begin(); n_2 != N_2.end(); ++n_2) {
      //Mark colors which are used by distance-2 neighbors in forbiddenColors
      if (get(vertex_color, G_b, *n_2)>0) {
	forbiddenColors[get(vertex_color, G_b, *n_2)] = *v;
      }
    }
    
    //Find first color which can be assigned to v
    vector<unsigned int>::iterator result = find_if(forbiddenColors.begin(),
						    forbiddenColors.end(),
						    bind1st(not_equal_to<int>(), *v)
						    );
    
    //Color v
    put(color,*v,distance(forbiddenColors.begin(),result));
  }
  
  // now the number of colors is computed 
  int max_color=0;
  for (vector<unsigned int>::const_iterator v = V.begin(); v != V.end(); ++v) {
    if (get(color,*v)>max_color) 
      max_color = get(color,*v);
  }
  cout<<"Number of Colors: "<<max_color<<endl;
  return max_color;
}

/* This method also computes a restricted d2-coloring, but now the
 * colors are chosen randomly, by picking one of the possible colors */
int RandomD2ColoringRestricted(Graph& G_b, const vector<unsigned int> V)
{
  property_map<Graph, vertex_color_t>::type color = get(vertex_color, G_b);
  vector<unsigned int> N_2;
  
  //Iterate over all vertices which should be colored
  for (vector<unsigned int>::const_iterator v = V.begin(); v != V.end(); ++v) 
  {
    //Get the distance-2 neighbors
    N_2 = neighbors::N_2restricted(G_b,*v);
    
    //Iterate over distance-2 neighbors
    vector<unsigned int> forbiddenColors=vector<unsigned int>();
    for (vector<unsigned int>::iterator n_2 = N_2.begin(); n_2 != N_2.end(); ++n_2) {
      //Mark colors which are used by distance-2 neighbors in forbiddenColors
      if (get(vertex_color, G_b, *n_2)>0 && !binary_search(forbiddenColors.begin(),forbiddenColors.end(),get(vertex_color,G_b,*n_2))) {
	forbiddenColors.push_back(get(vertex_color,G_b,*n_2));
      }
    }

    // find maximum forbidden color
    unsigned int max = 0;
    //cout<<"forbidden colors\n";
    for(vector<unsigned int>::iterator i = forbiddenColors.begin();i!=forbiddenColors.end();i++){
      if (*i > max ) max = *i;
    }
    
    //Generate Vector of all possible colors, i.e. all colors less than max
    //which are not forbidden
    vector<unsigned int> possibleColors=vector<unsigned int>();
    for(unsigned int i = 1; i<= max; i++){
      vector<unsigned int>::iterator it;
      it=find_if(forbiddenColors.begin(),forbiddenColors.end(),bind1st(equal_to<unsigned int>(),i));
      if (it==forbiddenColors.end())
	possibleColors.push_back(i);
    }
    // if no such colors are left, a new one is added
    if (size(possibleColors)==0) possibleColors.push_back(max+1);
    
    // one color is chosen randomly
    int pos = rand() % size(possibleColors);
    
    //Color v
    put(color,*v,possibleColors.at(pos));
    
  }
  
  // again, the number of colors is computed
  int max_color=0;
  for (vector<unsigned int>::const_iterator v = V.begin(); v != V.end(); ++v) {
    if (get(color,*v)>max_color) 
      max_color = get(color,*v);
  }
  cout<<"Number of Colors: "<<max_color<<endl;
  return max_color;
}



/* This Method checks a coloring whether it's valid */
int checkColoring(Graph& G_b,const vector<unsigned int> V){
  property_map<Graph, vertex_color_t>::type color=get(vertex_color,G_b);
  vector<unsigned int> N_2;
  // for all vertices, the distance 2 neighbors are computed and
  // the coloring is checked
  for(vector<unsigned int>::const_iterator v = V.begin();v!=V.end();++v){
    N_2 = neighbors::N_2restricted(G_b,*v);
    for (vector<unsigned int>::iterator n_2 = N_2.begin(); n_2 != N_2.end(); ++n_2) {
      if (*v!=*n_2 && get(vertex_color,G_b,*v) == get(vertex_color,G_b,*n_2)){
	cout<<"Wrong coloring!\n";
	return 0;
      }
    }
  }
  return 1;
}


/* Goes through all vertices and tries to add as many edges as possible */
int addAllElements(Graph& G_b, const vector<unsigned int> V)
{
  property_map<Graph, vertex_color_t>::type color=get(vertex_color,G_b);
  property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
  graph_traits<Graph>::edge_descriptor e;
  graph_traits<Graph>::adjacency_iterator neighbor,neighbor_end;
  graph_traits<Graph>::adjacency_iterator D2neighbor,D2neighbor_end;
  bool validNewElement=true;
  int counter=0;
  for(vector<unsigned int>::const_iterator v=V.begin(); v!=V.end();++v)
  {
    // for each neighbor of the current vertex, it is checked whether its
    // already colored neighbors have a different color. If yes, the edge
    // from the current vertex to the neighbor is marked.
    for(tie(neighbor,neighbor_end)=adjacent_vertices(*v,G_b);neighbor!=neighbor_end;neighbor++)
    {
      e=edge(*v,*neighbor,G_b).first;
      if(get(edge_weight,G_b,e)!=1){
	validNewElement = true; 
	for(tie(D2neighbor,D2neighbor_end)=adjacent_vertices(*neighbor,G_b);D2neighbor!=D2neighbor_end&&validNewElement;D2neighbor++)
	{
	  if(get(vertex_color,G_b,*D2neighbor)==get(vertex_color,G_b,*v) && *v!=*D2neighbor)
	    validNewElement = false;
	}
	if(validNewElement){
	  put(weight,edge(*v,*neighbor,G_b).first,1);
	  //cout<<"New edge: "<<*v<<" - "<<*neighbor<<endl;
	  counter++;
	}
      }
    }
  }
  return counter;
}

/* Add possible edges to a restricted starbicoloring */
int  addAllElementsBicoloring(Graph& G_b, const vector<unsigned int>& V_r, const vector<unsigned int>& V_c, vector<int>& color)
{
  property_map<Graph, edge_weight_t>::type weight = get(edge_weight,G_b);
  graph_traits<Graph>::edge_descriptor e;
  graph_traits<Graph>::adjacency_iterator w,w_end;
  graph_traits<Graph>::adjacency_iterator u,u_end;
  graph_traits<Graph>::adjacency_iterator x,x_end;
  bool validNewElement=true;
  int counter=0;
  // go through V_r to find possible edges to add
  for(vector<unsigned int>::const_iterator v=V_r.begin();v!=V_r.end();++v){
    // look at all edges
    for(tie(w,w_end)=adjacent_vertices(*v,G_b);w!=w_end;w++){
      e = edge(*v,*w,G_b).first;
      // only edges not yet required need to be considered
      if(get(edge_weight,G_b,e)!=1){
	if(color[*v]==0 && color[*w]==0){
	  // by condition 2 edge cannot be added, since both endpoints are not colored
	}
	else {
	  validNewElement=true;
	  // edge is still possible, condition 3 needs to be checked
	  // 3.1:
	  if (color[*v]==0 ){
	    for (tie(u,u_end)=adjacent_vertices(*v,G_b);u!=u_end;u++){
	      if(*w!=*u && color[*u] == color[*w]){
		validNewElement=false;
		break;
	      }
	    }
	  }
	  // 3.2
	  else if(validNewElement && color[*w]==0) {
	    for(tie(x,x_end)=adjacent_vertices(*w,G_b);x!=x_end;x++){
	      if(*v!=*x && color[*v]==color[*x]){
		validNewElement=false;
		break;
	      }
	    }
	  }
	  // 3.3
	  else if (validNewElement) {
	    for(tie(u,u_end)=adjacent_vertices(*v,G_b);u!=u_end;u++){
	      for(tie(x,x_end)=adjacent_vertices(*w,G_b);x!=x_end;x++){
		if(*u!=*w && *v!=*x && color[*u]==color[*w] && color[*v]==color[*x]){
		  validNewElement=false;
		  break;
		}
	      }
	      if(!validNewElement)
		break;
	    }
	  }
          
	  // add element if possible
	  if (validNewElement){
	    put(weight,e,1);
	    counter++;
	  }
	}
      }
    }
  }
  return counter;
}
