#ifndef DATATYPES_HPP
#define DATATYPES_HPP

#include "boost/config.hpp"
#include "boost/graph/adjacency_list.hpp"
#include "boost/cstdlib.hpp"

using namespace std;
using namespace boost;

typedef adjacency_list<vecS, vecS, undirectedS,
 		       property<vertex_color_t, int>,
 		       property<edge_weight_t, int,
		       property<edge_weight2_t, int> > > Graph;

typedef pair<vector<unsigned int>,set<unsigned int> > DualSet;

#endif
