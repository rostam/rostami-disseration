Compile MEX interfaces by executing make in directory GraphColoring/MEXinterface
